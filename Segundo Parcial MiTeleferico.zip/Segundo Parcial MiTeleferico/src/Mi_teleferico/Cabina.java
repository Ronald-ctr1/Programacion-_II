package miteleferico;
import java.util.ArrayList;
public class Cabina {
        int nroCabina;
    ArrayList<Persona> personasAbordo;

    public Cabina(int nroCabina) {
        this.nroCabina = nroCabina;
        this.personasAbordo = new ArrayList<>();
    }

    public boolean agregarPersona(Persona p) {
        personasAbordo.add(p);
        return true;
    }

    // Método auxiliar (permitido)
    public int cantidadPersonas() {
        return personasAbordo.size();
    }

    public float pesoTotal() {
        float total = 0;
        for (Persona p : personasAbordo) {
            total += p.pesoPersona;
        }
        return total;
    }
}
