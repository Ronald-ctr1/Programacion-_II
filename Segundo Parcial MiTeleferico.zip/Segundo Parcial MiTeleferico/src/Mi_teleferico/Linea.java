/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package miteleferico;

/**
 *
 * @author AREA_PROGRAMACION
 */
import java.util.ArrayList;

public class Linea {
    String color;
    ArrayList<Persona> filaPersonas;
    ArrayList<Cabina> cabinas;
    int cantidadCabinas;

    public Linea(String color) {
        this.color = color;
        this.filaPersonas = new ArrayList<>();
        this.cabinas = new ArrayList<>();
        this.cantidadCabinas = 0;
    }

    public void agregarPersona(Persona p) {
        filaPersonas.add(p);
    }

    public void agregarCabina(int nroCab) {
        cabinas.add(new Cabina(nroCab));
        cantidadCabinas = cabinas.size();
    }

    // Método permitido
    public Cabina getCabina(int nro) {
        for (Cabina c : cabinas)
            if (c.nroCabina == nro) return c;
        return null;
    }

    // Ingreso total con tarifas preferenciales y regulares
    public float ingresoTotal() {
        float total = 0;
        for (Cabina c : cabinas) {
            for (Persona p : c.personasAbordo) {
                if (p.edad < 25 || p.edad >= 60)
                    total += 1.5;
                else
                    total += 3;
            }
        }
        return total;
    }

    // Ingreso solo regular (3 bs)
    public float ingresoRegular() {
        float total = 0;
        for (Cabina c : cabinas) {
            total += c.personasAbordo.size() * 3;
        }
        return total;
    }
}


