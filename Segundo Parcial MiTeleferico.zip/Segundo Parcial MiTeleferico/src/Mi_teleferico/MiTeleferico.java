package miteleferico;
import java.util.ArrayList;

public class MiTeleferico {
    ArrayList<Linea> lineas;
    float cantidadIngresos;

    public MiTeleferico() {
        this.lineas = new ArrayList<>();
        this.cantidadIngresos = 0;
    }

    public void agregarPersonaFila(Persona p, String lineaColor) {
        for (Linea l : lineas)
            if (l.color.equalsIgnoreCase(lineaColor))
                l.agregarPersona(p);
    }

    public void agregarCabina(String lineaColor) {
        for (Linea l : lineas)
            if (l.color.equalsIgnoreCase(lineaColor))
                l.agregarCabina(l.cantidadCabinas + 1);
    }

    public void agregarLinea(Linea l) {
        lineas.add(l);
    }

    // Agregar primera persona a cabina X
    public boolean agregarPrimeraPersonaCabina(String lineaColor, int nroCab, Persona p) {
        for (Linea l : lineas) {
            if (l.color.equalsIgnoreCase(lineaColor)) {
                Cabina c = l.getCabina(nroCab);
                if (c == null) return false;

                // Cabina debe estar vacía
                if (c.cantidadPersonas() > 0) return false;

                // Peso permitido
                if (p.pesoPersona > 850) return false;

                // LÍMITES
                if (1 > 10) return false; // No se excede porque solo hay 1 persona

                c.agregarPersona(p);
                return true;
            }
        }
        return false;
    }
    // b) Verificar reglas
    public boolean verificarReglas() {
        for (Linea l : lineas) {
            for (Cabina c : l.cabinas) {

                if (c.cantidadPersonas() > 10)
                    return false;

                if (c.pesoTotal() > 850)
                    return false;
            }
        }
        return true;
    }
    //Ingreso total con tarifas
    public float calcularTotalIngresos() {
        float total = 0;
        for (Linea l : lineas) {
            total += l.ingresoTotal();
        }
        cantidadIngresos = total;
        return total;
    }
    //Línea con más ingreso regular
    public Linea lineaConMasIngresoRegular() {
        float mayor = -1;
        Linea mejor = null;

        for (Linea l : lineas) {
            float ingreso = l.ingresoRegular();
            if (ingreso > mayor) {
                mayor = ingreso;
                mejor = l;
            }
        }
        return mejor;
    }
}
