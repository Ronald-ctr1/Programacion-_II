/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package miteleferico;

/**
 *
 * @author AREA_PROGRAMACION
 */
public class Persona {
    String nombre;
    int edad;
    float pesoPersona;
    public Persona (String nombre, int edad, float pesoPersona){
        this.nombre = nombre;
        this.edad = edad;
        this.pesoPersona = pesoPersona;
}
}
